#include <jni.h>
#include <string>
#include <android/log.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

extern "C" JNIEXPORT jstring JNICALL
Java_cn_kinghell_embedded_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

static bool flag=false;

extern "C"  JNIEXPORT jboolean JNICALL Java_cn_kinghell_embedded_PasswordFragment_startLED(JNIEnv* env,jobject){
    jint fd=open("/dev/ledtest",O_RDWR | O_SYNC);
    if(fd==-1)
        return false;
    if(!flag){
        ioctl(fd,1,0);
        ioctl(fd,1,1);
        ioctl(fd,1,2);
        ioctl(fd,1,3);

        flag=true;
    }else{
            ioctl(fd,0,0);
            ioctl(fd,0,1);
            ioctl(fd,0,2);
            ioctl(fd,0,3);
            flag=false;
    }
    close(fd);

    return true;
}



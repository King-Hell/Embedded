package cn.kinghell.embedded

import java.net.URL

class Http:Runnable{

    init {

    }
    override fun run() {

    }

}
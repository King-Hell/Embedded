package cn.kinghell.embedded

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import kotlinx.android.synthetic.main.fragment_qr.*
import cn.bertsir.zbar.QrConfig
import cn.bertsir.zbar.QrManager


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [QRFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [QRFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class QRFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private var listener: OnFragmentInteractionListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        scanQR()
        return inflater.inflate(R.layout.fragment_qr, container, false)
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden) {
            scanQR()
        }
    }

    fun scanQR(){
        val qrConfig = QrConfig.Builder()
            .setDesText("(识别二维码)")//扫描框下文字
            .setShowDes(false)//是否显示扫描框下面文字
            .setShowLight(true)//显示手电筒按钮
            //.setShowTitle(true)//显示Title
            .setShowAlbum(true)//显示从相册选择按钮
            //.setCornerColor(Color.WHITE)//设置扫描框颜色
            //.setLineColor(Color.WHITE)//设置扫描线颜色
            //.setLineSpeed(QrConfig.LINE_MEDIUM)//设置扫描线速度
            .setScanType(QrConfig.TYPE_QRCODE)//设置扫码类型（二维码，条形码，全部，自定义，默认为二维码）
            .setScanViewType(QrConfig.SCANVIEW_TYPE_QRCODE)//设置扫描框类型（二维码还是条形码，默认为二维码）
            //.setCustombarcodeformat(QrConfig.BARCODE_I25)//此项只有在扫码类型为TYPE_CUSTOM时才有效
            .setPlaySound(true)//是否扫描成功后bi~的声音
            .setNeedCrop(true)//从相册选择二维码之后再次截取二维码
            //.setDingPath(R.raw.test)//设置提示音(不设置为默认的Ding~)
            .setIsOnlyCenter(true)//是否只识别框中内容(默认为全屏识别)
            .setTitleText("扫描二维码")//设置Tilte文字
            //.setTitleBackgroudColor(Color.BLUE)//设置状态栏颜色
            //.setTitleTextColor(Color.BLACK)//设置Title文字颜色
            .setShowZoom(false)//是否手动调整焦距
            .setAutoZoom(false)//是否自动调整焦距
            //.setScreenOrientation(QrConfig.SCREEN_LANDSCAPE)//设置屏幕方向
            .create()
        QrManager.getInstance().init(qrConfig).startScan(activity) { result ->
            Toast.makeText(context, result, Toast.LENGTH_SHORT).show();
        }
    }

    // TODO: Rename method, update argument and hook method into UI event
    fun onButtonPressed(uri: Uri) {
        listener?.onFragmentInteraction(uri)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnFragmentInteractionListener) {
            listener = context
        } else {
            throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
        }
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     *
     * See the Android Training lesson [Communicating with Other Fragments]
     * (http://developer.android.com/training/basics/fragments/communicating.html)
     * for more information.
     */
    interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment QRFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            QRFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }

    }

    external fun stringFromJNI(): String


}
